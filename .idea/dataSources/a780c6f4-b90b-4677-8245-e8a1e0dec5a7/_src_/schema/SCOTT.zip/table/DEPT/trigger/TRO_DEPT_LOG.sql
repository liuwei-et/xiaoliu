CREATE TRIGGER TRO_DEPT_LOG
BEFORE INSERT OR UPDATE OR DELETE
  ON DEPT
  declare val varchar2(20);
begin
if inserting then val :='有人增加数据了';
elsif deleting then val :='有人删除数据了';
elsif updating then val := '有人更新数据了';
end if;
insert into dept_log values(val,sysdate);
end;
/
