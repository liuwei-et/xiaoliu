CREATE VIEW KKK AS select ename,hiredate,empno,sal from emp where to_number(to_char(hiredate,'yyyy')) > 2000 order by sal
/
