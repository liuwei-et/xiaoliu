CREATE VIEW SNAME AS select ename,sal,hiredate,empno from emp where sal > 2000 order by sal
/
