CREATE VIEW AAS AS select empno,ename,to_char(hiredate,'yyyy') nian,sal from emp where sal > 100 and job = 'CLERK' order by sal desc
/
