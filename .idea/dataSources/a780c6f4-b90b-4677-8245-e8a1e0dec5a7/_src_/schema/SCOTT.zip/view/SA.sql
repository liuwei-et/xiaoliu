CREATE VIEW SA AS select kk.ename, kk.empno,to_char(hiredate,'yyyy') year, sal from emp kk where sal > 2000
and job = 'CLERK' order by sal desc
/
