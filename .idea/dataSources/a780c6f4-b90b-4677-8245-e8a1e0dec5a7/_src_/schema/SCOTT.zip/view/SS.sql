CREATE VIEW SS AS select kk.empno,kk.ename,to_char(hiredate,'yyyy') nian,sal from emp kk where sal > 2000 and job = 'CLERK' order by sal desc
/
