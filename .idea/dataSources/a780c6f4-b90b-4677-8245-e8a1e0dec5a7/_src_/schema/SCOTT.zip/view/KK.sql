CREATE VIEW KK AS select ename,hiredate,empno,sal from emp order by sal
/
