CREATE VIEW K AS select k.empno,k.ename,to_char(hiredate,'mm') a,k.sal,b.dname from emp k join dept b on  k.sal < 2000
and k.job = 'CLERK' order by sal asc
/
