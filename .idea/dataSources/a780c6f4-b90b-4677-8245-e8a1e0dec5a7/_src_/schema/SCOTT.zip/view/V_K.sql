CREATE VIEW V_K AS select yg.empno, yg.ename,dept.dname,to_char(yg.hiredate,'mm') kk , yg.sal from emp yg
 left join dept on yg.deptno = dept.deptno
left join emp ld on yg.mgr = ld.empno
 order by sal desc
/
