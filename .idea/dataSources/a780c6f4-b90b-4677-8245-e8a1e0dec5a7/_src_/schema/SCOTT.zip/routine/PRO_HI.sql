CREATE procedure pro_hi(cr in number, cc out varchar)
as
begin
if cr = 1 then cc:='你好坏';
else if cr = 2 then cc:'你好丑';
end if;
end if;
end;
/
