CREATE procedure pro_dd(cr in number,cc out varchar)









w

w

w
w
w
w

w/
//
/
