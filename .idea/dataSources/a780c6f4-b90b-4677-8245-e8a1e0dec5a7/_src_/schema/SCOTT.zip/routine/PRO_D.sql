CREATE procedure pro_d(cr in number,cc out varchar)
as
bengin
if cr = 1 then cc:='你好';
else if cr = 2 then cc:'你好丑';
end if;
end if;
end;
/
